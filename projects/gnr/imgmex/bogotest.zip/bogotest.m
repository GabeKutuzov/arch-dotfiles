% Test program for B. Obara's phase-congruency-vesselness package
% - Make gallery of images of figs using Canny edge detection and
%   phase-congruency-vesselness with a gallery of parameter sets.
% $Id: bogotest.m 3 2012-11-05 20:40:23Z  $
% V1A, 10/19/12, GNR - New script based on cit5x5.m and show_fig.m
% ==>, 10/19/12, GNR - Last mod before committing to svn repository

% Set NImgs to number of randomly chosen CIT images to analyze.
NImgs = 10;

% Set UseMedian true to use median filtered image as input to
%   vesselness (it will always be used for Canny).
UseMedian = false;         % Median filter with 3x3 window
PlotMedian = true;         % True to plot median-filtered image
DoPause = false;           % Pause after processing each image

% Parameter sets for phase-congruency-vesselness filter
% (Set 1 = defaults from BOFungalNetworkLabel2D_TEST.m)
PCV(1).beta    = 5.5;      % StdDev in eigenvalue ratio factor
PCV(1).Bogc    = 0.5;      % StdDev in eigenvalue sum factor
PCV(1).nscale  = 6;        % Number of spatical scales
PCV(1).norient = 6;        % Number of orientations
PCV(1).MnWaveL = 2.0;      % Minimum wave length (Kovesi likes 3)
PCV(1).Kovmult = 1.5;      % Scale factor between successive filters
PCV(1).SigOnF  = 0.6;      % Argument of log in denominator of Eqn. 14
PCV(1).KovK    = 2.0;      % Threshold in stddevs of noise energy

% (Set 2 = values in Obara paper)
PCV(2).beta    = 0.5;
PCV(2).Bogc    = 0.4;
PCV(2).nscale  = 5;  
PCV(2).norient = 6;  
PCV(2).MnWaveL = 2.0;
PCV(2).Kovmult = 1.5;
PCV(2).SigOnF  = 0.6;
PCV(2).KovK    = 2.0;
                                         
% (Set 3 = values in Kovesi paper)
PCV(3).beta    = 0.55;
PCV(3).Bogc    = 0.4;
PCV(3).nscale  = 4;  
PCV(3).norient = 6;  
PCV(3).MnWaveL = 3.0;
PCV(3).Kovmult = 2.0;
PCV(3).SigOnF  = 1.2;
PCV(3).KovK    = 2.0;
                                         
% (Set 4 = best values GNR found in a quick scan)
PCV(4).beta    = 1.0;
PCV(4).Bogc    = 0.4;
PCV(4).nscale  = 6;  
PCV(4).norient = 6;  
PCV(4).MnWaveL = 3.0;
PCV(4).Kovmult = 1.5;
PCV(4).SigOnF  = 1.2;
PCV(4).KovK    = 5.0;
                                         
% Image selection parameters
CITPath = '/home/cdr/Sentinel/CIT101Images/';
udata1 = '*C(1-100),I(1-$)'
% Arbitrary image edge limit
MxEdge = 600;
% Set Kops to sum of options described in citmexset.c:
% Add 1 to preserve color, 2 for clipping, 4 for masking.
Kops = uint32(6);

% Canny threshold (default empty matrix)
CannyThresh = [];

if DoPause, pause on; end

CitMexComm = citmexset(CITPath, MxEdge, MxEdge, udata1, Kops);

%% Acquire, process, and graph NImgs random images
for i=1:NImgs
   [img, isid] = citmexget(CitMexComm);
   jsid = uint16(isid);
   sid = sprintf('Image C=%hu,I=%hu', jsid(1),jsid(2));
   disp(sid)
   figure;
   colormap(gray)
   imagesc(img,[0 max(max(img))]);
   axis off
   axis image
   title(['Raw ' sid]);
   drawnow

   % Do median filtering
   % N.B.  By test conducted 04/30/12, medfilt2(img) and
   %     medfilt2(img, [3 3]) produce identical results.
   imgm = medfilt2(img);
   if PlotMedian
      figure
      colormap(gray)
      imagesc(imgm);
      axis off
      axis image
      title(['Median filtered ' sid]);
      drawnow
      end

   % Always do and plot Canny for comparison
   edgimg = 120*edge(imgm, 'canny', []);
   figure;
   colormap(gray)
   imagesc(edgimg);
   axis off
   axis image
   title(['Canny edged ' sid]);
   drawnow

   if UseMedian, wkim=imgm; else, wkim=img; end
   for i=1:numel(PCV)
      tic
      pcvim = vesselness(PCV(i).beta, PCV(i).Bogc, wkim, ...
         PCV(i).nscale, PCV(i).norient, PCV(i).MnWaveL, ...
         PCV(i).Kovmult, PCV(i).SigOnF, PCV(i).KovK);
      toc
      figure;
      colormap(gray)
      imagesc(pcvim);
      axis off
      axis image
      title(['PCV filtered, parm set ' num2str(i) ' ' sid]);
      drawnow
      end

   if DoPause, pause, end
   end   % Image loop

% All done, test shutdown call
citmexset(CitMexComm, 'close');
