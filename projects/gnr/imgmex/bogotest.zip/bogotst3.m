% Test program 3 for B. Obara's phase-congruency-vesselness package
% - Make gallery of images of figs using phase-congruency-vesselness
%   with "final" parameter sets and compare with Canny edges.
% $Id: bogotst3.m 9 2012-11-21 22:00:13Z  $
% V1A, 11/06/12, GNR - New script based on bogotst2.m
% ==>, 11/06/12, GNR - Last mod before committing to svn repository
% Rev, 11/07/12, GNR - Run without background painting as a test
% Rev, 11/12/12, GNR - Paint after vesselness anal w/10 pix border
% Rev, 11/21/12, GNR - Leave 3.1 pixel unpainted margin

% Set NImgs to number of randomly chosen CIT images to analyze.
NImgs = 12;

% Image selection parameters
CITPath = '/home/cdr/Sentinel/CIT101Images/';
udata1 = '*C(1-100),I(1-$)'
% Arbitrary image edge limit
MxEdgeX = [600 10 3.1];
MxEdgeY = [600 10];
% Set Kops to sum of options described in citmexset.c:
% Add 1 to preserve color, 2 for clipping, 4 for masking,
%  8 for deferred masking
Kops = uint32(10);

CitMexComm = citmexset(CITPath, MxEdgeX, MxEdgeY, udata1, Kops);

% Fixed parameters based on bogotst2 scans
nscale = 6;
norient = 6;
Kovmult = 1.5;
SigOnF = 1.5;
KovK = 3.0;
Bogc = 0.45;
MnWaveL = 2.5;
Bogbeta = 2.5;

%% Acquire, process, and graph NImgs random images
for i=1:NImgs
   [img, isid] = citmexget(CitMexComm);
   jsid = uint16(isid);
   sid = sprintf('Image C=%hu,I=%hu', jsid(1),jsid(2));
   disp(sid)

   figure;

   % Display raw image
   subplot(2,3,1);
   colormap(gray)
   imagesc(img);
   axis off
   axis image
   title(['Raw ' sid]);

   % Do median filtering for Canny edge detection
   imgm = medfilt2(img);
   subplot(2,3,4);
   colormap(gray)
   imagesc(imgm);
   axis off
   axis image
   title('Median filtered');

   % Do Obara vesselness filter and display
   try
      pcvim = vesselness(Bogbeta, Bogc, img, nscale, ...
         norient, MnWaveL, Kovmult, SigOnF, KovK);
   catch
      [m,n] = size(img);
      pcvim = 100*ones(m,n);
   end
   subplot(2,3,2);
   colormap(gray)
   imagesc(pcvim);
   axis off
   axis image
   title('Phase-congruency');

   bpvim = citmexpbg(CitMexComm, uint8(pcvim));
   subplot(2,3,5);
   colormap(gray)
   imagesc(bpvim);
   axis off
   axis image
   title('Painted phase-congruency');

   % Do Canny filter and display
   edgimg = 120*edge(imgm, 'canny', []);
   subplot(2,3,3);
   colormap(gray)
   imagesc(edgimg);
   axis off
   axis image
   title('Canny edged');

   bpedg = citmexpbg(CitMexComm, uint8(edgimg));
   subplot(2,3,6);
   colormap(gray)
   imagesc(bpedg);
   axis off
   axis image
   title('Painted Canny');

   end   % Image loop

% All done, test shutdown call
citmexset(CitMexComm, 'close');
