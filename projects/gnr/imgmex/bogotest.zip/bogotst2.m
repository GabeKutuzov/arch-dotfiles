% Test program for B. Obara's phase-congruency-vesselness package
% - Make gallery of images of figs using phase-congruency-vesselness
%   with a scan of parameter sets.
% $Id: bogotst2.m 6 2012-11-06 21:57:44Z  $
% V1A, 11/02/12, GNR - New script based on bogotest.m
% ==>, 11/02/12, GNR - Last mod before committing to svn repository
% V1B, 11/05/12, GNR - Correct bug that UseMedian was ignored.
%                      Shorten labels hoping to get larger images.
% Rev, 11/06/12, GNR - Second round parameter scan
% Rev, 11/06/12, GNR - Third round parameter scan

% Set NImgs to number of randomly chosen CIT images to analyze.
NImgs = 10;

% Set UseMedian true to use median filtered image as input
UseMedian = false;         % Median filter with 3x3 window
PlotInput = true;          % True to plot input image

% Image selection parameters
CITPath = '/home/cdr/Sentinel/CIT101Images/';
udata1 = '*C(1-100),I(1-$)'
% Arbitrary image edge limit
MxEdge = 600;
% Set Kops to sum of options described in citmexset.c:
% Add 1 to preserve color, 2 for clipping, 4 for masking.
Kops = uint32(6);

CitMexComm = citmexset(CITPath, MxEdge, MxEdge, udata1, Kops);

% Fixed parameters (for now)
nscale = 6;
norient = 6;
Kovmult = 1.5;

%% Acquire, process, and graph NImgs random images
for i=1:NImgs
   [img, isid] = citmexget(CitMexComm);
   jsid = uint16(isid);
   sid = sprintf('Image C=%hu,I=%hu', jsid(1),jsid(2));
   disp(sid)

   % Do median filtering if requested
   % N.B.  By test conducted 04/30/12, medfilt2(img) and
   %     medfilt2(img, [3 3]) produce identical results.
   if UseMedian, img = medfilt2(img); end
   if PlotInput
      figure
      colormap(gray)
      imagesc(img);
      axis off
      axis image
      drawnow
      end

   jim = 0;
   figure;
   Bogc = 0.45;
   for SigOnF = [1.4 1.5 1.6]     % Do not use 1.0
      for KovK = [3.0 4.0]
         %for Bogc = [0.45 0.55]
            for MnWaveL = [2.5 3.0]
               for Bogbeta = [2.0 2.5 3.0]
                  try
                     pcvim = vesselness(Bogbeta, Bogc, img, nscale, ...
                        norient, MnWaveL, Kovmult, SigOnF, KovK);
                  catch
                     [m,n] = size(img);
                     pcvim = 100*ones(m,n);
                  end
                  jim = jim + 1;
                  subplot(6,6,jim);
                  colormap(gray)
                  imagesc(pcvim);
                  axis off
                  axis image
                  lbl = sprintf(...
                     '%-.1f,%-.2f,%-.1f,%-.1f,%-.1f', ...
                     Bogbeta, Bogc, MnWaveL, SigOnF, KovK);
                  title(lbl);
                  end % Bogbeta loop
               end % MnWaveL loop
            %end % Bogc loop
         end % KofK loop
      end % SigOnF loop
   end   % Image loop

% All done, test shutdown call
citmexset(CitMexComm, 'close');
