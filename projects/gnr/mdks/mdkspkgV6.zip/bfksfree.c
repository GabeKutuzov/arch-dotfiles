/* (c) Copyright 2013, The Rockefeller University */
/* $Id: bfksfree.c 1 2014-04-21 19:53:00Z  $ */
/***********************************************************************
*           Multi-Dimensional Kolmogorov-Smirnov Statistic             *
*                             bfksfree.c                               *
*                                                                      *
*  This software was written by George N. Reeke in the Laboratory of   *
*  Biological Modelling at The Rockefeller University.  Please send    *
*  any corrections, suggestions, or improvements to the author by      *
*  email to reeke@mail.rockefeller.edu for possible incorporation in   *
*  future revisions.                                                   *
*                                                                      *
*  This software is distributed under GPL, version 2.  This program is *
*  free software; you can redistribute it and/or modify it under the   *
*  terms of the GNU General Public License as published by the Free    *
*  Software Foundation; either version 2 of the License, or (at your   *
*  option) any later version. Accordingly, this program is distributed *
*  in the hope that it will be useful, but WITHOUT ANY WARRANTY; with- *
*  out even the implied warranty of MERCHANTABILITY or FITNESS FOR A   *
*  PARTICULAR PURPOSE.  See the GNU General Public License for more    *
*  details.  You should have received a copy of the GNU General Public *
*  License along with this program.  If not, see                       *
*  <http://www.gnu.org/licenses/>.                                     *
*----------------------------------------------------------------------*
*                              bfksfree                                *
*                                                                      *
*  This function frees a work area allocated by bfksallox() for use in *
*  computation of the multi-dimensional Kolmogorov-Smirnov statistic.  *
*  This function is performed by a separate routine so that the same   *
*  work area can be reused for multiple MDKS calculations.  The same   *
*  routine is used for all bfks data-type variants, hence there is no  *
*  type version letter.  MATLAB uses an alternative bfksallox() call   *
*  q.v. to free the work area storage.                                 *
*                                                                      *
*  This is for the "brute-force" version of the MDKS package, intended *
*  only for test and timing comparison purposes.                       *
*                                                                      *
*  Usage:                                                              *
*     bfksfree() releases the storage associated with the work area    *
*  pointed to by the argument.                                         *
*                                                                      *
*  C or C++ Synopsis:                                                  *
*     int bfksfree(void *pwk)                                          *
*                                                                      *
*  Argument:                                                           *
*     pwk      This must be the pointer stored at *ppwk by a previous  *
*              call to bfksallox().                                    *
*                                                                      *
*  Return values:                                                      *
*     bfksfree() returns 0 on success and 1 if the argument 'pwk'      *
*  apparently did not point to an area allocated by an earlier call    *
*  to bfksallox().                                                     *
*                                                                      *
*  Reference:                                                          *
*     G. Fasano & A. Franceschini (1987).  A multidimensional version  *
*  of the Kolmogorov-Smirnov test.  Monthly Notices of the Royal       *
*  Astronomical Society, 225:155-170.                                  *
************************************************************************
*  V1A, 12/14/13, G.N. Reeke - New file, modified from mdksfree.c      *
*  ==>, 12/14/13, GNR - Last date before committing to svn repository  *
***********************************************************************/

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "mdks.h"
#include "bfksint.h"

int bfksfree(void *pwk) {

   Bfhd *phd = (Bfhd *)pwk;
   if (!phd || phd->hdrlbl != HLBL) return MDKSA_ERR_BADWK;

   /* Kill the hdrlbl in case user tries to reuse freed area */
   phd->hdrlbl = 0;

   free(pwk);

   return 0;
   } /* End bfksfree() */

