/* (c) Copyright 2013-2014, The Rockefeller University */
/* $Id: mdks.h 5 2014-05-27 17:36:19Z  $ */
/***********************************************************************
*                         MDKS.H Header File                           *
*           Multi-Dimensional Kolmogorov-Smirnov Statistic             *
*                                                                      *
*  This file contains declarations of the routines available in the    *
*  multi-dimensional Kolmogorov-Smirnov package.  These functions      *
*  compute the multi-dimensional Kolmogorov-Smirnov statistic, which   *
*  may be used to quantitate the degree to which two distributions of  *
*  points in k-dimensional space are statistically distinguishable.    *
*  The present versions can handle up to the number of data points     *
*  that will allow the work area to fit in memory, with k < 28.        *
*                                                                      *
*  The routines with names beginning "bfks" are the "brute-force"      *
*  version of the MDKS package, intended only for test and timing      *
*  comparison purposes.                                                *
*                                                                      *
*  The usage instructions for these programs are in the README file    *
*  and in the individual C source files.                               *
*                                                                      *
*  This software was written by George N. Reeke in the Laboratory of   *
*  Biological Modelling at The Rockefeller University.  Please send    *
*  any corrections, suggestions, or improvements to the author by      *
*  email to reeke@mail.rockefeller.edu for possible incorporation in   *
*  future revisions.                                                   *
*                                                                      *
*  This software is distributed under GPL, version 2.  This program is *
*  free software; you can redistribute it and/or modify it under the   *
*  terms of the GNU General Public License as published by the Free    *
*  Software Foundation; either version 2 of the License, or (at your   *
*  option) any later version. Accordingly, this program is distributed *
*  in the hope that it will be useful, but WITHOUT ANY WARRANTY; with- *
*  out even the implied warranty of MERCHANTABILITY or FITNESS FOR A   *
*  PARTICULAR PURPOSE.  See the GNU General Public License for more    *
*  details.  You should have received a copy of the GNU General Public *
*  License along with this program.  If not, see                       *
*  <http://www.gnu.org/licenses/>.                                     *
************************************************************************
*  V1A, 11/16/13, G.N. Reeke - New header file                         *
*  ==>, 02/08/14, GNR - Last date before committing to svn repository  *
*  Rev, 05/01/14, GNR - Add 'const' qualifiers to pointers to X1,X2    *
*  V6A, 05/10/14, GNR - Hierarchical bricks                            *
***********************************************************************/

#ifndef MDKS_HDR_INCLUDED
#define MDKS_HDR_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/* Routines to allocate and modify work areas */
int mdksallod(void **ppwk, int *g1, int *g2, int n1, int n2, int k);
int mdksallof(void **ppwk, int *g1, int *g2, int n1, int n2, int k);
int bfksallod(void **ppwk, int n1, int n2, int k);
int bfksallof(void **ppwk, int n1, int n2, int k);

/* Routine to release work area storage */
int mdksfree(void *pwk);
int bfksfree(void *pwk);

/* Define errors returned by mdksallox() and mdksfreex() */
#define MDKSA_ERR_BADWK    1
#define MDKSA_ERR_KLOW     2
#define MDKSA_ERR_KBIG     3
#define MDKSA_ERR_N1LOW    4
#define MDKSA_ERR_N2LOW    5
#define MDKSA_ERR_G1HIGH   6
#define MDKSA_ERR_G2HIGH   7
#define MDKSA_ERR_ADSPCE   8
#define MDKSA_ERR_NOMEM    9

/* Routines to compute the one-sided MDKS statistic */
double mdks1sd(void *pwk, double const *X1, double const *X2);
double mdks1sf(void *pwk, float const *X1, float const *X2);

/* Routines to compute the 2-sample (symmetric) MDKS statistic */
double mdks2sd(void *pwk, double const *X1, double const *X2);
double mdks2sf(void *pwk, float const *X1, float const *X2);

/* Routines to compute the MDKS statistic by brute-force methods
*  (basically for debugging and timing studies)  */
double bfks1sd(void *pwk, double const *X1, double const *X2);
double bfks1sf(void *pwk, float const *X1, float const *X2);
double bfks2sd(void *pwk, double const *X1, double const *X2);
double bfks2sf(void *pwk, float const *X1, float const *X2);

/* Define errors returned by mdks1sx() and mdks2sx() */
#define MDKS_ERR_BADWK   -1.0
#define MDKS_ERR_FLATX   -2.0

/* Routine to return pointers to the axial divisions */
int mdksdivs(void *pwk, int *pdivs[2]);

/* Routine to return compilation version of mdks library */
char *mdksvers(void);

#ifdef __cplusplus
}
#endif

#endif /* MDKS_HDR_INCLUDED */

