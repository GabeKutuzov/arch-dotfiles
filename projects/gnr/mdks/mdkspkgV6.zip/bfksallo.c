/* (c) Copyright 2013, The Rockefeller University */
/* $Id: bfksallo.c 1 2014-04-21 19:53:00Z  $ */
/***********************************************************************
*           Multi-Dimensional Kolmogorov-Smirnov Statistic             *
*                             bfksallo.c                               *
*                                                                      *
*  This software was written by George N. Reeke in the Laboratory of   *
*  Biological Modelling at The Rockefeller University.  Please send    *
*  any corrections, suggestions, or improvements to the author by      *
*  email to reeke@mail.rockefeller.edu for possible incorporation in   *
*  future revisions.                                                   *
*                                                                      *
*  This software is distributed under GPL, version 2.  This program is *
*  free software; you can redistribute it and/or modify it under the   *
*  terms of the GNU General Public License as published by the Free    *
*  Software Foundation; either version 2 of the License, or (at your   *
*  option) any later version. Accordingly, this program is distributed *
*  in the hope that it will be useful, but WITHOUT ANY WARRANTY; with- *
*  out even the implied warranty of MERCHANTABILITY or FITNESS FOR A   *
*  PARTICULAR PURPOSE.  See the GNU General Public License for more    *
*  details.  You should have received a copy of the GNU General Public *
*  License along with this program.  If not, see                       *
*  <http://www.gnu.org/licenses/>.                                     *
*----------------------------------------------------------------------*
*                              bfksallo                                *
*                                                                      *
*  This function allocates and initializes, or modifies for use with   *
*  data sets of different dimensionality, a bfks work area that is     *
*  used by the other routines in the bfks package.  This function is   *
*  performed by a separate routine so that the same work area can be   *
*  reused for multiple MDKS calculations.  This file also provides     *
*  routines to free the work area when no longer needed.               *
*                                                                      *
*  This is generic code that can be compiled with different external   *
*  definitions to generate routines to handle different data types.    *
*  This provides a mechanism in C similar to C++ templates.  Each      *
*  routine is named with a terminal letter to indicate the types it    *
*  handles.  This letter is represented by an 'x' in the comments.     *
*  The routines with the terminal letters are basically wrappers that  *
*  define the type selectors 'KTX' and 'KTN' and the version letter    *
*  'VL' and then include the actual code from this file.  These        *
*  wrappers can also be compiled with 'I_AM_MATLAB' defined to create  *
*  a MATLAB mex file with the same name that performs the same action. *
*                                                                      *
*  This is the "brute-force" version of the MDKS package, intended     *
*  only for test and timing comparison purposes.                       *
*                                                                      *
*  Usage to allocate or reallocate a work area:                        *
*     bfksallox() must be called before calls to any of the other      *
*  bfks routines or any time one of the parameters 'n1', 'n2', or 'k'  *
*  changes.  For example, bfks2sx() uses this call to reverse n1 and   *
*  n2 for computation of the two-sample (symmetric) version of the     *
*  statistic.  The value returned is an argument to the other func-    *
*  tions.  Once allocated, the same work area can be used for multi-   *
*  ple calculations as long as 'n1', 'n2', and 'k' are unchanged.      *
*                                                                      *
*     The size of the work area allocated by this routine depends only *
*  on the dimensionality 'k' and comprises 2*(2^k)*DSIZE bytes, plus   *
*  a small fixed amount for overhead, where DSIZE is the size of a     *
*  double-precision floating-point variable.                           *
*                                                                      *
*  MATLAB Synopsis:                                                    *
*     BFKSCOM = bfksallox(BFKSCOM, n1, n2, k)                          *
*  C or C++ Synopsis:                                                  *
*     int bfksallox(void **ppwk, NDAT_T n1, NDAT_T n2, int k)          *
*                                                                      *
*  Arguments:                                                          *
*     k        Number of dimensions of the data points, 1 <= k < 32.   *
*     n1       Number of points in distribution X1, k < n1 < 2^31.     *
*     n2       Number of points in distribution X2, k < n2 < 2^31.     *
*              (NDAT_T represents the type of 'n1' and 'n2' for which  *
*              the particular version of bfksallox was compiled.  The  *
*              type NDAT_T is determined by the compile-time variable  *
*              'KTN', which is 0 for 'int' and 1 for 'long'.  In the   *
*              MATLAB mex file call, n1, n2, and k are MATLAB double-  *
*              precision scalars (1x1 matrices).  The actual data are  *
*              passed as arguments to bfks1sx() or bfks2sx().)         *
*     ppwk     Pointer to a location where bfksallox() will return a   *
*              pointer to the work area described above.  The pointer  *
*              at *ppwk must be initialized to NULL for the first call *
*              to bfksallox()--a non-NULL value indicates that this    *
*              call is intended to update an existing work area at     *
*              that location for data with different size parameters.  *
*              The pointer at *ppwk must be passed as the first argu-  *
*              ment in each following call to bfks1sx(), bfks2sx(), or *
*              bfksfree().                                             *
*     BFKSCOM  MATLAB equivalent of pwk.  This should be an empty      *
*              array on the first call, otherwise a value returned     *
*              by a previous call if the intent is to modify an        *
*              existing work area.                                     *
*                                                                      *
*  Return values:                                                      *
*     bfksallox() returns (at *ppwk) a pointer to a work area that     *
*  will be used by bfks1sx() or bfks2sx() during its calculations.     *
*  The contents of this work area are not of interest to the calling   *
*  program.  Care should be taken not to use stale pointers if multi-  *
*  ple calls are made to bfksallox() with different 'ppwk', as the     *
*  work area may be moved to a new location if it needs to be expanded.*
*  In this case, the pointer at *ppwk will be modified.  The function  *
*  return from bfksallox() is an integer which is zero in case of      *
*  success.  Nonzero values indicate errors as follows:                *
*     (1) On an attempt to modify the work area, the value at *ppwk    *
*         did not appear to point to a previously allocated work area. *
*     (2) 'k' is negative or zero.                                     *
*     (3) 'k' equals or exceeds the number of bits in an int.          *
*     (4) 'n1' is not larger than 'k'.                                 *
*     (5) 'n2' is not larger than 'k'.                                 *
*     (8) The required amount of storage was not available.  In        *
*         this case the pointer at *ppwk is set to NULL.               *
*  Note:  Error codes (6) and (7) are not used with this program.      *
*  Note:  On calls to bfksallox() to modify an existing work area      *
*  for use with different values of n1, n2, or k, if the new work      *
*  area fits in the space already allocated, the area is reused,       *
*  otherwise, it is expanded via a realloc() call.  This minimizes     *
*  the number of system calls needed when working with data sets of    *
*  different sizes.  (If under caller control, reallocation can be     *
*  minimized by processing the larger data sets first.)                *
*                                                                      *
*  Usage to release storage occupied by a work area:                   *
*     bfksfree() releases storage previously allocated by bfksallox()  *
*  back to the operating system.  (This program is the same for all    *
*  argument types and thus has no version identifier letter 'x'.)      *
*  MATLAB uses a different call to bfksallox() to release a work area. *
*                                                                      *
*  MATLAB Synopsis to release a work area:                             *
*     bfksallox(BFKSCOM, 0)                                            *
*  C Synopsis:                                                         *
*     int bfksfree(void *pwk)                                          *
*                                                                      *
*  Arguments:                                                          *
*     pwk      This must be the pointer stored at *ppwk by a previous  *
*              call to bfksallox().                                    *
*     BFKSCOM  MATLAB equivalent of pwk.                               *
*                                                                      *
*  Return values:                                                      *
*     bfksfree() returns 0 on success and 1 if the argument 'pwk'      *
*  apparently did not point to an area allocated by an earlier call    *
*  to bfksallox().  The MATLAB mex file gives a terminal error if      *
*  the operation was not successful.                                   *
*                                                                      *
*  Design Note:                                                        *
*     Using a variant of bfksallox() as the MATLAB call to release a   *
*  work area allows it to access the location of the work area stored  *
*  in the static mxArray at pmxwk so that this array can be destroyed  *
*  and the pointer set NULL so as to inactivate the mexAtExit routine  *
*  that otherwise would be called and would cause an error attempting  *
*  to release storage that was already released.                       *
*                                                                      *
*  Reference:                                                          *
*     G. Fasano & A. Franceschini (1987).  A multidimensional version  *
*  of the Kolmogorov-Smirnov test.  Monthly Notices of the Royal       *
*  Astronomical Society, 225:155-170.                                  *
************************************************************************
*  V1A, 12/14/13, G.N. Reeke - New file, extracted from mdksallo.c     *
*  ==>, 12/14/13, GNR - Last date before committing to svn repository  *
***********************************************************************/

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifdef I_AM_MATLAB
#include "mex.h"
#endif
#include "mdks.h"
#include "bfksint.h"

/*=====================================================================*
*  N.B.  This program is intended to be included in a wrapper program  *
*  that defines the type specifiers KTX and KTN and the version iden-  *
*  tifier VL.  Alternatively, these variables can be defined in a      *
*  makefile.  If compiled without external definitions, bfksallo will  *
*  default to double-precision data with integer size parameters and   *
*  no name terminal letter.                                            *
*  (This indirect method is used because #if cannot test strings.)     *
*=====================================================================*/

#ifdef I_AM_MATLAB
#define MyName vfnmex("bfksallo",VL)

static mxArray *pmxwk = NULL;    /* Ptr to mxArray that contains pwk */
enum rhsargs { jwk, jn1, jn2, jk };

/*=====================================================================*
*                              bfksexit                                *
*                                                                      *
*  This is the exit function that gets run when the user exits MATLAB  *
*  or issues 'clear mex'.  It releases the work area storage and the   *
*  mxArray that points to it if that was not already done.  The free-  *
*  standing bfksfree() cannot be used for this purpose because it has  *
*  no way to access the static pmxwk (other than adding code to store  *
*  a pointer to it in system shared memory).                           *
*=====================================================================*/

static void bfksexit(void) {

   if (pmxwk) {
      Bfhd *phd = *(Bfhd **)mxGetData(pmxwk);
      if (!phd || phd->hdrlbl != HLBL) return;
      /* Kill the hdrlbl in case user tries to reuse freed area */
      phd->hdrlbl = 0;
      /* Free the storage */
      free(phd);
      mxDestroyArray(pmxwk);
      /* Indicate it is gone */
      pmxwk = NULL;
      }

   } /* End bfksexit() */

/*=====================================================================*
*                   bfksallox mex function wrapper                     *
*=====================================================================*/

void InnerAllo(int nlhs, mxArray *plhs[],
   int nrhs, const mxArray *prhs[]) {

   void *pwk;                    /* Ptr to mdks work area */
   void *pmxptr;                 /* Ptr to data in pmxwk */
   Nint  n1,n2;                  /* Array sizes converted to ints */
   int   k;                      /* Dimensionality */
   int   rc;                     /* Return code from bfksallox */

/* Standard MATLAB check for proper numbers of arguments */

   if (nlhs == 1 && nrhs == 4) goto BfksDoAllo;
   else if (nlhs == 0 && nrhs == 2) goto BfksDoFree;
   else
      mexErrMsgTxt(MyName " expects 1 LH + 4 RH or 0 LH + 2 RH args.");

/* MATLAB call to free bfks work area */

BfksDoFree:

   /* Check that the n1 argument is 0 -- this is just a sanity check */
   if (!mxIsDouble(prhs[jn1]) ||
         mxGetNumberOfElements(prhs[jn1]) != 1 ||
         mxGetScalar(prhs[jn1]) != 0.0)
      mexErrMsgTxt(MyName " n1 arg must be 0 to free work area.");

   /* Extract the pointer to the work area from the jwk arg */
   if (!mxIsUint8(prhs[jwk]) ||
         mxGetNumberOfElements(prhs[jwk]) != sizeof(void *))
      mexErrMsgTxt(MyName " BFKSCOM arg is not expected type,size.");
   pwk = *(void **)mxGetData(prhs[jwk]);

   /* Be sure it is the same as the pointer stored at pmxwk */
   if (!pmxwk)
      mexErrMsgTxt(MyName " attempt to free work area already freed.");
   if (pwk != *(void **)mxGetData(pmxwk))
      mexErrMsgTxt(MyName " BFKSCOM arg is not current work area.");

   /* Free the work area */
   bfksexit();
   return;

/* MATLAB call to allocate or modify bfks work area */

BfksDoAllo:

   /* Copy pwk from the first RHS arg because it may get changed
   *  and we should not try to change it in situ.  */
   if (mxIsEmpty(prhs[jwk])) pwk = NULL;
   else if (!mxIsUint8(prhs[jwk]) ||
         mxGetNumberOfElements(prhs[jwk]) != sizeof(void *))
      mexErrMsgTxt(MyName " BFKSCOM arg is not expected type,size.");
   else pwk = *(void **)mxGetData(prhs[0]);

   /* Convert the RH args to ints */
   if (!mxIsDouble(prhs[jn1]) || mxGetNumberOfElements(prhs[jn1]) != 1)
      mexErrMsgTxt(MyName " n1 arg must be double-prec scalar.");
   n1 = (Nint)mxGetScalar(prhs[jn1]);

   if (!mxIsDouble(prhs[jn2]) || mxGetNumberOfElements(prhs[jn2]) != 1)
      mexErrMsgTxt(MyName " n2 arg must be double-prec scalar.");
   n2 = (Nint)mxGetScalar(prhs[jn2]);

   if (!mxIsDouble(prhs[jk]) || mxGetNumberOfElements(prhs[jk]) != 1)
      mexErrMsgTxt(MyName " k arg must be double-prec scalar.");
   k = (int)mxGetScalar(prhs[jk]);

   /* Allocate or update the work area */
   rc = vfnname(bfksallo,VL)(&pwk, n1, n2, k);
   if (rc != 0)
      mexErrMsgIdAndTxt("mex:" MyName, " Returned error %d\n.", rc);

   /* If not already there, allocate a pmxwk array to store pwk
   *  for possible use later for releasing the work area.  */
   if (!pmxwk) {
      pmxwk = mxCreateNumericMatrix(sizeof(void *), 1,
         mxUINT8_CLASS, mxREAL);
      mexMakeArrayPersistent(pmxwk);
      mexAtExit(bfksexit);
      }
   pmxptr = mxGetData(pmxwk);
   memcpy(pmxptr, &pwk, sizeof(void *));

   /* Now allocate a second copy to return to the caller */
   plhs[0] = mxCreateNumericMatrix(sizeof(void *), 1,
      mxUINT8_CLASS, mxREAL);
   pmxptr = mxGetData(plhs[0]);
   memcpy(pmxptr, &pwk, sizeof(void *));

   } /* End mexFunction */

/*** DEBUG - WRAPPER FOR THE WRAPPER ***/
void mexFunction(int nlhs, mxArray *plhs[],
   int nrhs, const mxArray *prhs[]) {

   InnerAllo(nlhs, plhs, nrhs, prhs);

   }
/*** ENDDEBUG ***/

#endif /* I_AM_MATLAB */

/*=====================================================================*
*                              bfksallox                               *
*=====================================================================*/

/* Macro to align an item size to that of largest type used */
#define AlignUp(sz) (((sz + llal - 1)/llal) * llal)

int vfnname(bfksallo,VL)(void **ppwk, Nint n1, Nint n2, int k) {

   char *pwk;
   Bfhd *phd;
   size_t lhdr,lwk,ltot,llal;

   /* If there is a valid existing work area, and new sizes are
   *  same as old, there is no need to do anything.  */
   if ((phd = (Bfhd *)*ppwk)) {     /* Assignment intended */
      if (phd->hdrlbl != HLBL)   return MDKSA_ERR_BADWK;
      if (n1 == phd->n[IX1] && n2 == phd->n[IX2] && k == phd->k)
         return 0;
      }

   /* Sanity checks on args */
   if (k <= 0)                   return MDKSA_ERR_KLOW;
   if (k >= NBPB*sizeof(Nint))   return MDKSA_ERR_KBIG;
#ifdef BFKS
   if (k >= 28 - KTX)            return MDKSA_ERR_KBIG;
#endif
   if (n1 <= k)                  return MDKSA_ERR_N1LOW;
   if (n2 <= k)                  return MDKSA_ERR_N2LOW;

   /* Compute size to align parts of work area */
   llal = sizeof(void *);
   if (sizeof(double) > llal) llal = sizeof(double);

   /* Compute size of work area */
   lhdr = AlignUp(sizeof(Bfhd));
   ltot = AlignUp((1 << k)*sizeof(double));
   lwk = lhdr + NDSET*ltot;

   /* If there is no existing work area, allocate one now.  If there
   *  is an existing work area and the new one will fit in the allo-
   *  cation of the old one, just reuse it.  Otherwise, use realloc()
   *  to make it big enough and replace the contents that differ.  */
   if (!phd) {
      if (!(*ppwk = malloc(lwk))) return MDKSA_ERR_NOMEM;
      }
   else if (lwk > phd->lallo) {
      if (!(*ppwk = realloc(*ppwk, lwk))) return MDKSA_ERR_NOMEM;
      }
   phd = (Bfhd *)(pwk = *ppwk), pwk += lhdr;

   /* Fill in the Bfhd */
   phd->pQtot[IX1] = (double *)pwk, pwk += ltot;
   phd->pQtot[IX2] = (double *)pwk;
   phd->nrat = (double)n1/(double)n2;
   phd->sqrtn1 = sqrt((double)n1);
   phd->lallo = lwk;
   phd->n[IX1] = n1;
   phd->n[IX2] = n2;
   phd->k = k;
   phd->hdrlbl = HLBL;

   return 0;

   } /* End bfksallox() */

