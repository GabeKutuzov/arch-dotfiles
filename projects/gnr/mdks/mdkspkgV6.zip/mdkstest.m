% Multidimensional Kolmogorov-Smirnov (MDKS) statistic test
% (c) The Rockefeller University, 2013
% $Id: mdkstest.m 3 2014-04-30 21:22:39Z  $

function [] = mdkstest()

%  This software was developed in the Laboratory of Biological
% Modelling at The Rockefeller University by George N. Reeke

%  This file tests the MDKS code by running it alongside a brute-
% force MATLAB-coded version of the test and a brute-force mex-file
% version of the test on all combinations of the following data sets:
% (1) One, two, three, and four-dimensional data.
% (2) 200, 1000, 5000, and 25000 data points.
% (3) Uniform, normal, and Gamma distributed data.
% (4) Single-sided and double-sided tests.
% Only double precision, only equal sizes of the two data sets, and
%   only default axial divisions are tested.  However, alternatives
%   to these options were tested by the author.
% Test results and execution times are reported.  The number of
% repetitions of each test may be set to obtain reasonable run times.

% LICENSE:
%  This software is distributed under GPL, version 2.
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or (at
% your option) any later version.  Accordingly, this program is distri-
% buted in the hope that it will be useful, but WITHOUT ANY WARRANTY;
% without even the implied warranty of MERCHANTABILITY or FITNESS FOR
% A PARTICULAR PURPOSE.  See the GNU General Public License for more
% details.  You should have received a copy of the GNU General Public
% License along with this program.
% If not, see <http://www.gnu.org/licenses/>.

%% User-settable parameters defining the random distributions
Mxreps = 500;           % Maximum repeats to do for any case
Ulow = 0;               % Low end of uniform distribution
Uhigh = 1;              % High end of uniform distribution
Nmean = 20;             % Mean of normal distribution
Nsigma = 5;             % Sigma of normal distribution
Gk = 1.5;               % Shape of gamma distribution
Gscl = 10;              % Scale of gamma distribution

%% Do the runs
MDKSCOM = [];
BFKSCOM = [];
RNames = { 'uniform'; 'normal'; 'gamma' };
for k = 1:5
   % Running n in this order tests ability of mdskallo to
   % reallocate to higher or lower work area sizes.
   for n = [200 25000 5000 1000]
      MDKSCOM = mdksallod(MDKSCOM, [], [], n, n, k);
      BFKSCOM = bfksallod(BFKSCOM, n, n, k);
      nreps = floor(1000000/(k*n));
      if nreps < 1, nreps = 1; end
      if nreps > Mxreps, nreps = Mxreps; end
      for r = 1:3
         mlks1 = zeros(nreps,1); mlks2 = zeros(nreps,1);
         bfks1 = zeros(nreps,1); bfks2 = zeros(nreps,1);
         mxks1 = zeros(nreps,1); mxks2 = zeros(nreps,1);
         tml1s = 0; tml2s = 0;
         tbf1s = 0; tbf2s = 0;
         tmx1s = 0; tmx2s = 0;
         for rep = 1:nreps
            switch r
            case 1
               % Uniform data
               X1 = random('unif',Ulow,Uhigh,k,n);
               X2 = random('unif',Ulow,Uhigh,k,n);
            case 2
               X1 = random('norm',Nmean,Nsigma,k,n);
               X2 = random('norm',Nmean,Nsigma,k,n);
            case 3
               X1 = random('gam',Gk,Gscl,k,n);
               X2 = random('gam',Gk,Gscl,k,n);
            end % Random type switch

%% Single-sided

            if k < 4
               tic
               mlks1(rep,1) = bfdiff(X1, X2)/sqrt(n);
               tml1s = tml1s + toc;
            end

            % brute-force mex-function
            tic
            bfks1(rep,1) = bfks1sd(BFKSCOM, X1, X2);
            tbf1s = tbf1s + toc;

            % brick mex-function method
            tic
            mxks1(rep,1) = mdks1sd(MDKSCOM, X1, X2);
            tmx1s = tmx1s + toc;

%% Two-sided

            if k < 4
               tic
               s1 = bfdiff(X1, X2);
               s2 = bfdiff(X2, X1);
               mlks2(rep,1) = (s1 + s2)*sqrt(0.125/n);
               tml2s = tml2s + toc;
            end

            % brute-force mex-function
            tic
            bfks2(rep,1) = bfks2sd(BFKSCOM, X1, X2);
            tbf2s = tbf2s + toc;

            % brick mex-function method
            tic
            mxks2(rep,1) = mdks2sd(MDKSCOM, X1, X2);
            tmx2s = tmx2s + toc;

            end % Loop over rep

%% Report averages and times

         [DivsX1, DivsX2] = mdksdivs(MDKSCOM);
         fprintf('\nFor k = %d, n = %d, %s distribution, divs = (%d,%d)\n', ...
            k, n, RNames{r}, DivsX1(1), DivsX2(1))
         if k < 4
            fprintf(['   Brute-force ML mean MDKS1s = %f, sigma MDKS1s' ...
               ' = %f, time = %f\n'], mean(mlks1), std(mlks1), tml1s/nreps);
         end
         fprintf(['   Brute-force mex mean MDKS1s = %f, sigma MDKS1s' ...
            ' = %f, time = %f\n'], mean(bfks1), std(bfks1), tbf1s/nreps);
         fprintf(['   Brick method mean MDKS1s = %f, sigma MDKS1s' ...
            ' = %f, time = %f\n'], mean(mxks1), std(mxks1), tmx1s/nreps);
         if k < 4
            fprintf(['   Brute-force ML mean MDKS2s = %f, sigma MDKS2s' ...
               ' = %f, time = %f\n'], mean(mlks2), std(mlks2), tml2s/nreps);
         end
         fprintf(['   Brute-force mex mean MDKS2s = %f, sigma MDKS2s' ...
            ' = %f, time = %f\n'], mean(bfks2), std(bfks2), tbf2s/nreps);
         fprintf(['   Brick method mean MDKS2s = %f, sigma MDKS2s' ...
            ' = %f, time = %f\n'], mean(mxks2), std(mxks2), tmx2s/nreps);

         end % Loop over r
      end % Loop over n
   end % Loop over k

%% Finish up

   mdksallod(MDKSCOM, 0);
   bfksallod(BFKSCOM, 0);
   fprintf('MDKS timing and accuracy test completed.');
   end

%% Function to perform the brute-force generalized-quadrant sums--
%  based on code in original version of hcentropy

function bfd = bfdiff(X1, X2)

   k = size(X1,1);
   n = size(X1,2);
   bfd = 0;
   switch k
   case 1
      for i = 1:n
         X1low = numel(find(X1(1,:) <= X1(1,i)));
         X2low = numel(find(X2(1,:) <= X1(1,i)));
         bfd = max(bfd, abs(X1low-X2low));
         end
   case 2
      for i = 1:n
         X1LLHC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) < X1(2,i)));
         X1LRHC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) < X1(2,i)));
         X1ULHC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) > X1(2,i)));
         X1URHC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) > X1(2,i)));
         X2LLHC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) < X1(2,i)));
         X2LRHC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) < X1(2,i)));
         X2ULHC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) > X1(2,i)));
         X2URHC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) > X1(2,i)));
         quads = [ abs(X1LLHC - X2LLHC); ...
                     abs(X1LRHC - X2LRHC); ...
                     abs(X1ULHC - X2ULHC); ...
                     abs(X1URHC - X2URHC); ];
         mxquad = max(quads);
         bfd = max(bfd, mxquad);
         end
   case 3
      for i = 1:n
         X1LLFOC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) < X1(2,i) & X1(3,:) < X1(3,i)));
         X1LRFOC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) < X1(2,i) & X1(3,:) < X1(3,i)));
         X1ULFOC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) > X1(2,i) & X1(3,:) < X1(3,i)));
         X1URFOC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) > X1(2,i) & X1(3,:) < X1(3,i)));
         X2LLFOC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) < X1(2,i) & X2(3,:) < X1(3,i)));
         X2LRFOC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) < X1(2,i) & X2(3,:) < X1(3,i)));
         X2ULFOC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) > X1(2,i) & X2(3,:) < X1(3,i)));
         X2URFOC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) > X1(2,i) & X2(3,:) < X1(3,i)));
         X1LLBOC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) < X1(2,i) & X1(3,:) > X1(3,i)));
         X1LRBOC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) < X1(2,i) & X1(3,:) > X1(3,i)));
         X1ULBOC = numel(find(X1(1,:) < X1(1,i) & X1(2,:) > X1(2,i) & X1(3,:) > X1(3,i)));
         X1URBOC = numel(find(X1(1,:) > X1(1,i) & X1(2,:) > X1(2,i) & X1(3,:) > X1(3,i)));
         X2LLBOC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) < X1(2,i) & X2(3,:) > X1(3,i)));
         X2LRBOC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) < X1(2,i) & X2(3,:) > X1(3,i)));
         X2ULBOC = numel(find(X2(1,:) < X1(1,i) & X2(2,:) > X1(2,i) & X2(3,:) > X1(3,i)));
         X2URBOC = numel(find(X2(1,:) > X1(1,i) & X2(2,:) > X1(2,i) & X2(3,:) > X1(3,i)));
         octs = [ abs(X1LLFOC - X2LLFOC); ...
                  abs(X1LRFOC - X2LRFOC); ...
                  abs(X1ULFOC - X2ULFOC); ...
                  abs(X1URFOC - X2URFOC); ...
                  abs(X1LLBOC - X2LLBOC); ...
                  abs(X1LRBOC - X2LRBOC); ...
                  abs(X1ULBOC - X2ULBOC); ...
                  abs(X1URBOC - X2URBOC); ];
         mxoct = max(octs);
         bfd = max(bfd, mxoct);
         end
   end % k switch
   end % bfdiff function

