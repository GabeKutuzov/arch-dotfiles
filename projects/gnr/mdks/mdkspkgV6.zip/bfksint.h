/* (c) Copyright 2013, The Rockefeller University */
/* $Id: bfksint.h 1 2014-04-21 19:53:00Z  $ */
/***********************************************************************
*           Multi-Dimensional Kolmogorov-Smirnov Statistic             *
*                              bfksint.h                               *
*                                                                      *
*  This software was written by George N. Reeke in the Laboratory of   *
*  Biological Modelling at The Rockefeller University.  Please send    *
*  any corrections, suggestions, or improvements to the author by      *
*  email to reeke@mail.rockefeller.edu for possible incorporation in   *
*  future revisions.                                                   *
*                                                                      *
*  This software is distributed under GPL, version 2.  This program is *
*  free software; you can redistribute it and/or modify it under the   *
*  terms of the GNU General Public License as published by the Free    *
*  Software Foundation; either version 2 of the License, or (at your   *
*  option) any later version. Accordingly, this program is distributed *
*  in the hope that it will be useful, but WITHOUT ANY WARRANTY; with- *
*  out even the implied warranty of MERCHANTABILITY or FITNESS FOR A   *
*  PARTICULAR PURPOSE.  See the GNU General Public License for more    *
*  details.  You should have received a copy of the GNU General Public *
*  License along with this program.  If not, see                       *
*  <http://www.gnu.org/licenses/>.                                     *
*----------------------------------------------------------------------*
*                               bfksint                                *
*                                                                      *
*  This header file contains definitions used internally by routines   *
*  in the bfks package.  These should be of no concern to programs     *
*  that are using routines in this package.                            *
*                                                                      *
*  This is for the "brute-force" version of the MDKS package, intended *
*  only for test and timing comparison purposes.                       *
*                                                                      *
*  Documentation of the functions and their usage is in the README     *
*  file and in the individual C source files.                          *
************************************************************************
*  V1A, 12/14/13, G.N. Reeke - Declarations modified from mdks.c       *
*  ==>, 12/14/13, GNR - Last date before committing to svn repository  *
***********************************************************************/

/*=====================================================================*
*  N.B.  Programs using this header are intended to be included in a   *
*  wrapper program that defines the type specifiers KTX and KTN and    *
*  the version identifier VL.  Alternatively, these variables can be   *
*  defined in a makefile.  If compiled without external definitions,   *
*  bfks routines will default to double-precision data with integer    *
*  'ni' and no name suffix.                                            *
*  (This indirect method is used because #if cannot test strings.)     *
*=====================================================================*/

#ifndef BFKSINT_HDR_INCLUDED
#define BFKSINT_HDR_INCLUDED

/* Define the type used for the X1 and X2 data ('float' or 'double') */
#ifndef KTX
#define KTX 1
#endif
#if KTX == 0
typedef float Xdat;
#elif KTX == 1
typedef double Xdat;
#else
#undef KTX
#error KTX must be 1 (for double) or 0 (float) or add code for new type
#endif
/* Define the type used for 'n' (usually 'int' but could be a
*  longer type) */
#ifndef KTN
#define KTN 0
#endif
#if KTN == 0
typedef int Nint;
#else
typedef long Nint;
#endif
/* Define a macro to append a version letter to a function name to
*  give a unique name to the version compiled for the above types.
*  (This crazy nested macro is needed because the '##' operator
*  does not perform substitution on its arguments.)  */
#ifdef  VL
#define vfncat(fn,vlet)  fn ## vlet
#define vfnname(fn,vlet) vfncat(fn,vlet)
#define vfnmcat(fn,vlet) fn #vlet
#define vfnmex(fn,vlet)  vfnmcat(fn,vlet)
#else
#define vfnname(fn,vlet) fn
#define vfnmex(fn,vlet) fn
#endif

/* Code assumes the following defined values--change only with care */
#define HLBL  0x42464B53   /* Header label: Ascii "BFKS" */
#define NBPB    8          /* Number of bits in a byte */
#define NDIMS   2          /* Dimensions of MATLAB X arguments */
#define NDSET   2          /* Number of data sets being compared */
#define IX1     0          /* Index of data for data set X1 */
#define IX2     1          /* Index of data for data set X2 */
typedef unsigned char  byte;
typedef unsigned short ui16;
typedef unsigned int   ui32;

/* Work area header */
struct Bfhd_t {
   double *pQtot[NDSET];   /* Ptrs to quad totals for X1, X2 */
   double nrat;            /* n1/n2 */
   double sqrtn1;          /* sqrt(n1) */
   size_t lallo;           /* Size allocated to this Wkhd */
   Nint n[NDSET];          /* Number of points in X1, X2 */
   int  hdrlbl;            /* Label to validate work area */
   int  k;                 /* Dimension of the problem */
   };
typedef struct Bfhd_t Bfhd;

#endif /* BFKSINT_HDR_INCLUDED */
